Some small helper function that accumulated over the last few months. Maybe they are useful to someone.
